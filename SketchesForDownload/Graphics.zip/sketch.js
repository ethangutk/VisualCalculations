//         Tunnel Simulation!          //
// You can change the range of motion and
// how far apart each circle is from one
// another.

let rangeOfMotion = 0.1; // range of 2 to 20+;
let circleDistance = 0.9; // Range of 0.2 to 0.8;

//
//
//
//
// ---------------------------------- //


function setup() {
  createCanvas(750, 750);
  background(40);

  noFill();
  stroke(255);
}

function draw() {
  background(40);
  let xx = map (mouseX, 0, width, width / 2 - rangeOfMotion, width / 2 + rangeOfMotion);  
  let yy = map (mouseY, 0, height, height / 2 - rangeOfMotion, height / 2 + rangeOfMotion);  
  
  myCircle(xx, yy, 400, 50);
}

function myCircle(x, y, d, stage) {
  if (stage == 0) {
    return;
  }

  circle(x, y, d);
  //let y = map(mouseY / (height / 2), 0, width, )
  let ratioY = mouseY / (height / 2);
  let ratioX = mouseX / (width / 2);
  myCircle(x * ratioX, y * ratioY, d * circleDistance, stage - 1);
}


