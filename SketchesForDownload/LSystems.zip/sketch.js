//       L-Systems       //
//                       //
//                       //
//                       //
//                       //
// --------------------- //

let lsystems = [
    "Fractal (binary) tree",
    "Cantor set",
    "Koch curve",
    "Sierpinski triangle",
    "Dragon curve",
    "Fractal plant",
    "Hilbert's Curve",
    "My Custom Fractal",
  ],
  lsystemIndex = 0,
  slider,
  axiom = "0",
  rules = [
    ["1", "11"],
    ["0", "1[0]0"],
  ],
  angle = 45,
  drawLineLength = 15;

function setup() {
  noLoop(); // This will stop the draw function from LOOPing
  frameRate(0);
  createCanvas(600, 600);

  // Set up GUI
  button = createButton("Change L-System");
  button.position(10, height + 10);
  button.style("width", "200px");
  button.style("height", "40px");
  button.mousePressed(changeLSystem);
  slider = createSlider(0, 7, 0);
  slider.position(10, height + 70);
  slider.style("width", "200px");
  slider.input(draw);

  // Show initial set
  console.log("Starting with " + lsystems[lsystemIndex]);
}

function draw() {
  noCanvas();
  createCanvas(600, 600);
  background(200);
  
  
  // Move turtle
  if (lsystemIndex == 0 || lsystemIndex == 1 || lsystemIndex == 5) {
    translate(width / 2, height - 5);
    drawLineLength = 10 / slider.value();
    
  } else if (lsystemIndex == 2 || lsystemIndex == 3 || lsystemIndex == 6) {
     translate(5, height - 5);
    drawLineLength = 40 / slider.value();
    
  } else {
    translate(width / 2, height/2);
    drawLineLength = 10;
    
  }
  
  let lsysString = updateString(slider.value(), axiom);

  stroke(255, 0, 0);
  strokeWeight(3);

  for (let i = 0; i < lsysString.length; i++) {
    stroke(255, 0, 0);
    if (lsystemIndex == 0) {
      // Fractal (binary) tree
      if (lsysString[i] == "[") {
        push();
        rotate(radians(-angle));
      } else if (lsysString[i] == "]") {
        pop();
        rotate(radians(angle));
      } else {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      }
    } 
    else if (lsystemIndex == 1) { // Cantor set
      // Cantor set
      if (lsysString[i] == "A") {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      } else if (lsysString[i] == "B") {
        translate(0, -drawLineLength);
      }
    } 
    else if (lsystemIndex == 2) { // Koch curve
      // Cantor set
      if (lsysString[i] == "F") {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      } else if (lsysString[i] == "+") {
        rotate(radians(angle));
      } else if (lsysString[i] == "-") {
        rotate(radians(-angle));
      }
    }
    else if (lsystemIndex == 3 || lsystemIndex == 4) { // Sierpinski triangle & Dragon curve
      // Cantor set
      if (lsysString[i] == "F" || lsysString[i] == "G") {
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      } else if (lsysString[i] == "+") {
        rotate(radians(-angle));
      } else if (lsysString[i] == "-") {
        rotate(radians(angle));
      }
    }
    else if (lsystemIndex == 5) { // Fractal plant
      if (lsysString[i] == "[") {
        push();
        rotate(radians(-angle));
      } else if (lsysString[i] == "]") {
        pop();
      } else if (lsysString[i] == "+") {
        rotate(radians(angle));
      } else if (lsysString[i] == "-") {
        rotate(radians(-angle));
      } else if (lsysString[i] == "F")  {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      }
    } else if (lsystemIndex == 6) { // Hilbert's Curve
    
      if (lsysString[i] == "+") {
        rotate(radians(angle));
      } else if (lsysString[i] == "-") {
        rotate(radians(-angle));
      } else if (lsysString[i] == "Z")  {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      }
     } else if (lsystemIndex == 7) { // My Custom
      if (lsysString[i] == "[") {
        push();
      } else if (lsysString[i] == "]") {
        pop();
      } else if (lsysString[i] == "+") {
        rotate(radians(angle));
      } else if (lsysString[i] == "-") {
        rotate(radians(-angle));
      } else if (lsysString[i] == "E")  {
        stroke(random(255), 0, 0);
        line(0, 0, 0, -drawLineLength);
        translate(0, -drawLineLength);
      }
     }    
  }
}
/*



Helper Functions:



*/

function updateString(stage, currString) {
  let newString = "";
  // If the stage is at zero, return
  if (stage == 0) {
    return currString;
  }

  // Otherwise loop through all of the characters and
  // replacing the characters with rules.
  for (let i = 0; i < currString.length; i++) {
    for (let j = 0; j < rules.length; j++) {
      if (currString[i] == "["){
        newString += "[";
        break;
      } else if (currString[i] == "]") {
        newString += "]";
        break;
      } else if (currString[i] == "+") {
        newString += "+";
        break;
      } else if (currString[i] == "-") {
        newString += "-";
        break;
      }else if (currString[i] == "Z") {
        newString += "Z";
        break;
      }

      if (currString[i] == rules[j][0][0]) {
        newString += rules[j][1];
        continue;
      }
    }
  }

  return updateString(stage - 1, newString);
}

function changeLSystem() {
  if (lsystemIndex == lsystems.length - 1) {
    lsystemIndex = 0;
  } else {
    lsystemIndex++;
  }
  console.log("Changed to " + lsystems[lsystemIndex] + " " + lsystemIndex);

  if (lsystemIndex == 0) {
    // Fractal (binary) tree
    axiom = "0";
    rules = [
      ["1", "11"],
      ["0", "1[0]0"],
    ];
    angle = 45;
  } else if (lsystemIndex == 1) {
    // Cantor set
    axiom = "A";
    rules = [
      ["A", "ABA"],
      ["B", "BBB"],
    ];
    angle = undefined;
  } else if (lsystemIndex == 2) {
    // Koch curve
    axiom = "F";
    rules = [["F", "F+F-F-F+F"]];
    angle = 90;
  } else if (lsystemIndex == 3) {
    // Sierpinski triangle
    axiom = "F-G-G";
    rules = [
      ["F", "F-G+F+G-F"],
      ["G", "GG"],
    ];
    angle = 120;
  } else if (lsystemIndex == 4) {
    // Dragon curve
    axiom = "F";
    rules = [
      ["F", "F+G"],
      ["G", "F-G"],
    ];
    angle = 90;
  } else if (lsystemIndex == 5) {
    // Fractal plant
    axiom = "X";
    rules = [
      ["X", "F+[[X]-X]-F[-FX]+X"],
      ["F", "FF"],
    ];
    angle = 25;
  } else if (lsystemIndex == 6) {
    // Hilbert's Curve
    axiom = "A";
    rules = [
      ["A", "+BZ-AZA-ZB+"],
      ["B", "-AZ+BZB+ZA-"],
    ];
    angle = 90;
  } else if (lsystemIndex == 7) {
    // My Custom
    axiom = "E";
    rules = [["E", "+[E--]+EEE--"]
            ];
    angle = 30;
  }

  stroke(255, 0, 0);
  point(0, 0);

  draw();
}
