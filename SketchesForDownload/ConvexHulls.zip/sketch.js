/*
     ------ CONVEX HULLS - JARVIS MARCH ------
     ------   MADE BY: ETHAN GUTKNECHT  ------

This final project explores convex hulls of given points.
There are two main algorithms that explore this topic
but I will be focusing on the Jarvis march algorithm.
You are able to change the settings of thise code below.
*/

// Settings:
let minPoints = 10;
let maxPoints = 500; // It will get slow over 1000

/*











*/

// Global Variables:
let points = [],
  sidePoints = [];
let startPoint;
let numberOfPoints = maxPoints / 2;

function setup() {
  // Create canvas
  createCanvas(750, 750); // CANNOT BE BELOW 150 x 150

  if (maxPoints < minPoints || minPoints < 10) {
    console.log(" --- ERROR ---");
    console.log(
      "Fix point variables. minPoints must be greater than ten and maxPoints must be greater than minPoints."
    );
    return;
  }
  performFunctions();

  slider = createSlider(minPoints, maxPoints, maxPoints / 2);
  slider.position(25, height + 20);
  slider.style("width", "590px");
  slider.changed(() => {
    numberOfPoints = slider.value();
    performFunctions();
  });

  button = createButton("Redraw Points");
  button.position(width - 100, height + 20);
  button.mousePressed(performFunctions);
}

// Everytime the slider updates and
// when the sketch initially starts,
// this function is called.
function performFunctions() {
  // Create canvas
  background(200);

  // Show "How many points text"
  textSize(24);
  strokeWeight(5);
  stroke(255);
  text(numberOfPoints + " points", 10, height - 10);
  fill(0);

  // Clear out old variables;
  (points = []), (sidePoints = []);
  startPoint = undefined;

  // Create points
  createPoints(numberOfPoints);

  jarvisMarchAlgorithm();
}

// This is the helper method that actually
// performs the algorithm.
function jarvisMarchAlgorithm() {
  //  - - - - - Variables - - - - -
  let currentLeftmost = undefined;

  //  - - - - - Find starting point - - - - -
  for (let i = 0; i < points.length; i++) {
    if (i == 0 || points[i].x < startPoint.x) {
      startPoint = points[i];
    }
  }
  stroke(0, 255, 0);
  point(startPoint.x, startPoint.y);
  sidePoints.push(startPoint);
  stroke(40);

  //  - - - - - Loop through all points - - - - -
  // Worse case, it will loop through all of the points.
  // this is very rare
  for (let i = 0; i < points.length; i++) {
    // Everytime you loop through the points, clear the current left most
    currentLeftmost = undefined;

    for (let j = 0; j < points.length; j++) {
      // Retrieve the first point of the loop and assign it the left most
      if (currentLeftmost == undefined) {
        if (points[j] == startPoint) continue;
        currentLeftmost = points[j];
        continue;
      }

      /*
      This is the area where I got stuck originally. I worked with cross products
      before in CSE 386 and I was mildly familiar with it but I couldn't grasp that
      it could be used here. The youtube video (resource 1) helped me out here. His
      approach was animated and a bit different than mine but it he explains the logic 
      behind it really well around 11:53 and it all came together.
      */
      let vectorToCheck = p5.Vector.sub(points[j], startPoint);
      let vectorCLM = p5.Vector.sub(currentLeftmost, startPoint);
      if (vectorToCheck.cross(vectorCLM).z > 0 && points[j] != startPoint) {
        // If it is more left most (cross product > 0) and the current
        // point is not the starting point then update the next left most.
        currentLeftmost = points[j];
      }
    }

    // Draw the line to the next point and update the start point
    strokeWeight(3);
    stroke(map(i, 0, 14, 0, 220), map(i, 0, 14, 255, 0), 0);
    line(currentLeftmost.x, currentLeftmost.y, startPoint.x, startPoint.y);
    startPoint = currentLeftmost;

    // On the case where the current left most point
    // make it back to the start point, end the algorithm.
    // Otherwise, add it to the array
    if (sidePoints[0] == startPoint) {
      break;
    } else {
      sidePoints.push(startPoint);
    }
  }

  // Plot all of the side points and display point text
  for (let i = 0; i < sidePoints.length; i++) {
    strokeWeight(10);
    stroke(255, 0, 0);
    if (i == 0) {
      stroke(0, 255, 0);
      strokeWeight(20);
    }
    point(sidePoints[i].x, sidePoints[i].y);
    strokeWeight(5);
    stroke(255);
    text(
      i + 1,
      sidePoints[i].x - map(sidePoints[i].x + 50, 0, width, 60, -30),
      sidePoints[i].y - map(sidePoints[i].y + 50, 0, height, 60, -30)
    );
    fill(0);
  }
}

// NOTE: The canvas size MUST be over 150x150 due to
// the code giving the points margines.
function createPoints(numOfPoints) {
  strokeWeight(10);
  stroke(40);
  for (let i = 0; i < numOfPoints; i++) {
    let newPoint = createVector(
      random(width - 150) + 75,
      random(height - 150) + 75
    );
    points.push(newPoint);
    point(newPoint.x, newPoint.y);
  }
}

// ---------------------------------------------------------------------- //
/*
    RESOURCES:
 ----- #1 -----
 Coding Challenge #148: Gift Wrapping Algorithm (Convex Hull)
 https://www.youtube.com/watch?v=YNyULRrydVI

 ----- #2 -----
 Gift wrapping algorithm
 https://en.wikipedia.org/wiki/Gift_wrapping_algorithm
 
 ----- #3 -----
 Convex Hull Algorithm - Graham Scan and Jarvis March tutorial
 https://www.youtube.com/watch?v=B2AJoQSZf4M
 
 ----- #4 -----
 Convex Hull Algorithm
 https://www.tutorialcup.com/interview/algorithm/convex-hull-algorithm.htm
*/

// ---------------------------------------------------------------------- //
/*
    RANDOM NOTES:
    
  Logic for looping through all of the points:
    loop through all points in brute force way
      you would pick the first point in the loop to be currentLeftmost
      find cross product of loopPoint and currentLeft (have to do vector subtraction)
      if z is negative AND not startingPoint, this means that the loop point
        is now the current left most point, so update.

*/
// ---------------------------------------------------------------------- //
