// Global Variables
let bailout;
let ESCAPE_RADIUS = 3.0;
let C, farEscapeColor, closeEscapeColor, nonEscapeColor, savedImage, mouseOnCanvas,
    canvas, tries, minDomain, maxDomain, sliderMax, sliderMin, sliderStep, slider,
    expon = 2, exponMax;



function setup() {
  /*
  ---------------------------------
  You can change majority of this 
  drawing's settings here
  ---------------------------------
  */
  // --The Canvas Size--
  canvas = createCanvas(600, 600);
  
  // --Color Scheme--
  nonEscapeColor = color(0, random(255),random(255));
  farEscapeColor = color(255,0,0);
  closeEscapeColor = color(255,128,128);
  
  // --Domain of the Complex numbers--
  minDomain = -2;
  maxDomain = 2;
  
  // Slider Max and min
  sliderMax = 20;
  sliderMin = 1;
  sliderStep = 1;
  
  // Expo Max
  exponMax = 6;
  
  /*
  ---------------------------------
         Set up sketch here
  ---------------------------------
  */
  savedImage = createGraphics(width, height);
  C = new Complex(0.01, 0.86);
  slider = createSlider(sliderMin, sliderMax, 13, sliderStep);
  bailout = slider.value();
  slider.position(10, height + 20);
  slider.style('width', '380px');
  slider.changed(() => {
    bailout = slider.value();
    console.log("Updating bailout value to " + slider.value());
    drawJuliaSet();
  });
  
  mouseOnCanvas = false;
  canvas.mouseOut(out);
  canvas.mouseOver(inside);
  drawJuliaSet();
}



/*
--------------
Main Functions
--------------
*/
function drawJuliaSet() {
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let real = map(x, 0, width - 1, minDomain, maxDomain);
      let imag = map(y, 0, height - 1, minDomain, maxDomain);
      let seed = new Complex(real, imag);

      if (escapes(seed, false)) {
        set(x, y, lerpColor(closeEscapeColor, farEscapeColor, (tries/bailout)));
      } else {
        set(x, y, nonEscapeColor);
      }
    }
  }
  updatePixels();

  fill(0,0,0);
  stroke(200);
  strokeWeight(2);
  textSize(16);
  textStyle(BOLD);
  text('f(x) = x^' + expon + ' + ' + C.getReal() +' + ' + C.getImag() + 'i', 10, 20);
  text("bailout: " + bailout, 10, 44);
  
  
  
  // Copy of my sketch to saved image
  savedImage.copy(canvas, 0, 0, width, height, 0, 0, width, height);
  
}

function mouseReleased() {
  if (mouseOnCanvas) {
    let newr = map(mouseX, 0, width, minDomain, maxDomain);
    let newi = map(mouseY, 0, height, minDomain, maxDomain);

    C = new Complex(round(newr, 4), round(newi, 4));
    drawJuliaSet();
  }
}

function keyPressed() {
  if (keyCode === RIGHT_ARROW && expon < exponMax) {
    expon++;
    drawJuliaSet();
  } else if (keyCode === LEFT_ARROW && expon > 2) {
    expon--;
    drawJuliaSet();
  } else return;
  console.log("Changed exponent to " + expon);
}

// These two functions needed to check to see if
// the mouse is inside the canvas for the slider function.
function out() {
  mouseOnCanvas = false;
}

function inside() {
  mouseOnCanvas = true;
}

function escapes(x, isDrawingPoints) {
  let lastX, lastY;
  let currX, currY;
  
  tries = 0;
  while (tries <= bailout) {
    if (isDrawingPoints && mouseOnCanvas) {
      // Set up storage for saving last points
      if (tries != 0) {
        lastX = currX;
        lastY = currY;
      }
      currX = map(x.getReal(), minDomain, maxDomain, 0, width);
      currY = map(x.getImag(), minDomain, maxDomain, 0, height);
      
      // Draw line (if able) and point.
      if (tries != 0) {
        strokeWeight(1);
        line(lastX, lastY, currX, currY);
      }
      strokeWeight(5);
      point(currX, currY);
    }
    if (x.abs() > ESCAPE_RADIUS) {
      return true;
    }
    x = f(x);
    tries++;
  }
 
  // made it here? Never escaped in time
  return false;
}

function draw() {
  copy(savedImage, 0, 0, width, height, 0, 0, width, height);
  
  let newr = map(mouseX, 0, width, minDomain, maxDomain);
  let newi = map(mouseY, 0, height, minDomain, maxDomain);
  let currMouseLocation = new Complex(newr, newi);
  
  escapes(currMouseLocation, true);
  
  
}

function f(x) {
  let rx = x;
  for (let i = 1; i <= expon ; i++) {
    rx = rx.mult(rx);
  }
  return rx.add(C);
}


/*

Create a complex number object.

*/

class Complex {
  constructor(a, b) {
    this.a = a; // Real
    this.b = b; // Image
  }
  
  getReal() {
    return this.a;
  }
  
  getImag() {
    return this.b;
  }
  
  // Add one complex number with another as a param
  add(other) {
    return new Complex(this.a + other.a, this.b + other.b);
  }

  // Multiply one complex number with another as a param
  mult(other) {
    let real = (this.a * other.a) + (-1 * other.b * this.b);
    let imag = (this.b * other.a) + (this.a * other.b);
    return new Complex(real, imag);
  }

  // Return the absolute value of this complex number which is
  // its distance from (0,0)
  abs() {
    return dist(this.a, this.b, 0, 0);
  }
}
